from typing import List
from ast_nodes import *


class BytecodeGenerator:
    def __init__(self):
        self.code: List[str] = []
        self.label_count = 0

    def new_label(self) -> str:
        self.label_count += 1
        return f"LBL{self.label_count}"

    def generate(self, program: Program) -> List[str]:
        for stmt in program.statements:
            self.gen_statement(stmt)
        self.code.append("HALT")
        return self.code

    def gen_statement(self, node: ASTNode) -> None:
        if isinstance(node, VarDecl):
            self.code.append(f"DECLARE {node.name}")
            return

        if isinstance(node, Assignment):
            self.gen_expression(node.value)
            self.code.append(f"STORE {node.name}")
            return

        if isinstance(node, Print):
            self.gen_expression(node.value)
            self.code.append("PRINT")
            return

        if isinstance(node, If):
            else_label = self.new_label()
            end_label = self.new_label()
            self.gen_expression(node.condition)
            self.code.append(f"JUMP_IF_FALSE {else_label}")
            for stmt in node.then_branch.statements:
                self.gen_statement(stmt)
            self.code.append(f"JUMP {end_label}")
            self.code.append(f"LABEL {else_label}")
            if node.else_branch:
                for stmt in node.else_branch.statements:
                    self.gen_statement(stmt)
            self.code.append(f"LABEL {end_label}")
            return

        if isinstance(node, While):
            start_label = self.new_label()
            end_label = self.new_label()
            self.code.append(f"LABEL {start_label}")
            self.gen_expression(node.condition)
            self.code.append(f"JUMP_IF_FALSE {end_label}")
            for stmt in node.body.statements:
                self.gen_statement(stmt)
            self.code.append(f"JUMP {start_label}")
            self.code.append(f"LABEL {end_label}")
            return

        raise ValueError(f"Nó bytecode não suportado: {type(node).__name__}")

    def gen_expression(self, node: ASTNode) -> None:
        if isinstance(node, Literal):
            if node.literal_type == "bool":
                self.code.append(f"PUSH_BOOL {str(node.value).lower()}")
            elif node.literal_type == "string":
                self.code.append(f"PUSH_STRING {node.value!r}")
            else:
                self.code.append(f"PUSH_INT {node.value}")
            return

        if isinstance(node, Identifier):
            self.code.append(f"LOAD {node.name}")
            return

        if isinstance(node, Read):
            self.code.append("READ")
            return

        if isinstance(node, UnaryOp):
            self.gen_expression(node.operand)
            if node.operator == "-":
                self.code.append("NEG")
            return

        if isinstance(node, BinaryOp):
            self.gen_expression(node.left)
            self.gen_expression(node.right)
            op_map = {
                "+": "ADD",
                "-": "SUB",
                "*": "MUL",
                "/": "DIV",
                "==": "EQ",
                "!=": "NEQ",
                "<": "LT",
                ">": "GT",
            }
            self.code.append(op_map[node.operator])
            return

        raise ValueError(f"Expressão bytecode não suportada: {type(node).__name__}")
