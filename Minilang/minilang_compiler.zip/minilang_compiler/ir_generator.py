from typing import List
from ast_nodes import *


class IRGenerator:
    def __init__(self):
        self.code: List[str] = []
        self.temp_count = 0
        self.label_count = 0

    def new_temp(self) -> str:
        self.temp_count += 1
        return f"t{self.temp_count}"

    def new_label(self) -> str:
        self.label_count += 1
        return f"L{self.label_count}"

    def generate(self, program: Program) -> List[str]:
        for stmt in program.statements:
            self.gen_statement(stmt)
        return self.code

    def gen_statement(self, node: ASTNode) -> None:
        if isinstance(node, VarDecl):
            self.code.append(f"decl {node.var_type} {node.name}")
            return

        if isinstance(node, Assignment):
            value = self.gen_expression(node.value)
            self.code.append(f"{node.name} = {value}")
            return

        if isinstance(node, Print):
            value = self.gen_expression(node.value)
            self.code.append(f"print {value}")
            return

        if isinstance(node, If):
            else_label = self.new_label()
            end_label = self.new_label()
            cond = self.gen_expression(node.condition)
            self.code.append(f"ifFalse {cond} goto {else_label}")
            for stmt in node.then_branch.statements:
                self.gen_statement(stmt)
            self.code.append(f"goto {end_label}")
            self.code.append(f"{else_label}:")
            if node.else_branch:
                for stmt in node.else_branch.statements:
                    self.gen_statement(stmt)
            self.code.append(f"{end_label}:")
            return

        if isinstance(node, While):
            start_label = self.new_label()
            end_label = self.new_label()
            self.code.append(f"{start_label}:")
            cond = self.gen_expression(node.condition)
            self.code.append(f"ifFalse {cond} goto {end_label}")
            for stmt in node.body.statements:
                self.gen_statement(stmt)
            self.code.append(f"goto {start_label}")
            self.code.append(f"{end_label}:")
            return

        raise ValueError(f"Nó IR não suportado: {type(node).__name__}")

    def gen_expression(self, node: ASTNode) -> str:
        if isinstance(node, Literal):
            if node.literal_type == "bool":
                return "true" if node.value else "false"
            if node.literal_type == "string":
                return repr(node.value)
            return str(node.value)

        if isinstance(node, Identifier):
            return node.name

        if isinstance(node, Read):
            temp = self.new_temp()
            self.code.append(f"{temp} = read")
            return temp

        if isinstance(node, UnaryOp):
            operand = self.gen_expression(node.operand)
            temp = self.new_temp()
            self.code.append(f"{temp} = {node.operator}{operand}")
            return temp

        if isinstance(node, BinaryOp):
            left = self.gen_expression(node.left)
            right = self.gen_expression(node.right)
            temp = self.new_temp()
            self.code.append(f"{temp} = {left} {node.operator} {right}")
            return temp

        raise ValueError(f"Expressão IR não suportada: {type(node).__name__}")
