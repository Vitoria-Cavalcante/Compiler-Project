from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Token:
    type: str
    value: str
    line: int
    column: int

    def __repr__(self) -> str:
        return f"Token({self.type}, {self.value!r}, line={self.line}, col={self.column})"


class LexerError(Exception):
    pass


class Lexer:
    RESERVED = {
        "int": "INT",
        "bool": "BOOL",
        "if": "IF",
        "else": "ELSE",
        "while": "WHILE",
        "print": "PRINT",
        "read": "READ",
        "true": "TRUE",
        "false": "FALSE",
    }

    SINGLE_CHAR_TOKENS = {
        "+": "PLUS",
        "-": "MINUS",
        "*": "STAR",
        "/": "SLASH",
        "<": "LT",
        ">": "GT",
        "=": "ASSIGN",
        ";": "SEMICOLON",
        "(": "LPAREN",
        ")": "RPAREN",
        "{": "LBRACE",
        "}": "RBRACE",
    }

    TWO_CHAR_TOKENS = {
        "==": "EQ",
        "!=": "NEQ",
    }

    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1

    def current_char(self) -> Optional[str]:
        if self.pos >= len(self.source):
            return None
        return self.source[self.pos]

    def peek(self, offset: int = 1) -> Optional[str]:
        index = self.pos + offset
        if index >= len(self.source):
            return None
        return self.source[index]

    def advance(self) -> Optional[str]:
        ch = self.current_char()
        if ch is None:
            return None
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def skip_whitespace_and_comments(self) -> None:
        while True:
            ch = self.current_char()
            if ch is None:
                return

            if ch.isspace():
                self.advance()
                continue

            # Comentário de linha: // texto
            if ch == "/" and self.peek() == "/":
                while self.current_char() not in (None, "\n"):
                    self.advance()
                continue

            # Comentário de bloco: /* texto */
            if ch == "/" and self.peek() == "*":
                self.advance()
                self.advance()
                while True:
                    if self.current_char() is None:
                        raise LexerError(f"Comentário de bloco não fechado na linha {self.line}")
                    if self.current_char() == "*" and self.peek() == "/":
                        self.advance()
                        self.advance()
                        break
                    self.advance()
                continue

            return

    def read_identifier_or_reserved(self) -> Token:
        start_line, start_col = self.line, self.column
        text = ""
        while self.current_char() is not None and (self.current_char().isalnum() or self.current_char() == "_"):
            text += self.advance()
        token_type = self.RESERVED.get(text, "IDENT")
        return Token(token_type, text, start_line, start_col)

    def read_number(self) -> Token:
        start_line, start_col = self.line, self.column
        text = ""
        while self.current_char() is not None and self.current_char().isdigit():
            text += self.advance()
        return Token("NUMBER", text, start_line, start_col)

    def read_string(self) -> Token:
        start_line, start_col = self.line, self.column
        self.advance()  # abre aspas
        text = ""
        while self.current_char() is not None and self.current_char() != '"':
            if self.current_char() == "\n":
                raise LexerError(f"String não fechada na linha {start_line}, coluna {start_col}")
            text += self.advance()
        if self.current_char() != '"':
            raise LexerError(f"String não fechada na linha {start_line}, coluna {start_col}")
        self.advance()  # fecha aspas
        return Token("STRING", text, start_line, start_col)

    def tokenize(self) -> List[Token]:
        tokens: List[Token] = []

        while self.current_char() is not None:
            self.skip_whitespace_and_comments()
            ch = self.current_char()
            if ch is None:
                break

            start_line, start_col = self.line, self.column
            two = ch + (self.peek() or "")

            if two in self.TWO_CHAR_TOKENS:
                self.advance()
                self.advance()
                tokens.append(Token(self.TWO_CHAR_TOKENS[two], two, start_line, start_col))
                continue

            if ch.isalpha() or ch == "_":
                tokens.append(self.read_identifier_or_reserved())
                continue

            if ch.isdigit():
                tokens.append(self.read_number())
                continue

            if ch == '"':
                tokens.append(self.read_string())
                continue

            if ch in self.SINGLE_CHAR_TOKENS:
                self.advance()
                tokens.append(Token(self.SINGLE_CHAR_TOKENS[ch], ch, start_line, start_col))
                continue

            raise LexerError(f"Caractere inválido {ch!r} na linha {start_line}, coluna {start_col}")

        tokens.append(Token("EOF", "", self.line, self.column))
        return tokens
