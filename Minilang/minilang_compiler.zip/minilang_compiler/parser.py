from typing import List
from lexer import Token
from ast_nodes import (
    Program, Block, VarDecl, Assignment, Print, Read, If, While,
    BinaryOp, UnaryOp, Literal, Identifier, ASTNode
)


class ParserError(Exception):
    pass


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0

    def current(self) -> Token:
        return self.tokens[self.pos]

    def previous(self) -> Token:
        return self.tokens[self.pos - 1]

    def check(self, token_type: str) -> bool:
        return self.current().type == token_type

    def match(self, *token_types: str) -> bool:
        if self.current().type in token_types:
            self.pos += 1
            return True
        return False

    def consume(self, token_type: str, message: str) -> Token:
        if self.check(token_type):
            token = self.current()
            self.pos += 1
            return token
        token = self.current()
        raise ParserError(f"{message}. Encontrado {token.type} ({token.value!r}) na linha {token.line}, coluna {token.column}")

    def parse(self) -> Program:
        statements = []
        while not self.check("EOF"):
            statements.append(self.statement())
        return Program(statements)

    def statement(self) -> ASTNode:
        if self.match("INT", "BOOL"):
            return self.var_declaration(self.previous())
        if self.match("IDENT"):
            return self.assignment(self.previous())
        if self.match("PRINT"):
            return self.print_statement()
        if self.match("IF"):
            return self.if_statement()
        if self.match("WHILE"):
            return self.while_statement()
        token = self.current()
        raise ParserError(f"Comando inesperado {token.type} ({token.value!r}) na linha {token.line}, coluna {token.column}")

    def var_declaration(self, type_token: Token) -> VarDecl:
        name = self.consume("IDENT", "Esperado identificador após tipo")
        self.consume("SEMICOLON", "Esperado ';' após declaração de variável")
        return VarDecl(type_token.value, name.value)

    def assignment(self, name_token: Token) -> Assignment:
        self.consume("ASSIGN", "Esperado '=' após identificador")
        value = self.expression()
        self.consume("SEMICOLON", "Esperado ';' após atribuição")
        return Assignment(name_token.value, value)

    def print_statement(self) -> Print:
        self.consume("LPAREN", "Esperado '(' após print")
        value = self.expression()
        self.consume("RPAREN", "Esperado ')' após expressão do print")
        self.consume("SEMICOLON", "Esperado ';' após print")
        return Print(value)

    def if_statement(self) -> If:
        self.consume("LPAREN", "Esperado '(' após if")
        condition = self.expression()
        self.consume("RPAREN", "Esperado ')' após condição do if")
        then_branch = self.block()
        else_branch = None
        if self.match("ELSE"):
            else_branch = self.block()
        return If(condition, then_branch, else_branch)

    def while_statement(self) -> While:
        self.consume("LPAREN", "Esperado '(' após while")
        condition = self.expression()
        self.consume("RPAREN", "Esperado ')' após condição do while")
        body = self.block()
        return While(condition, body)

    def block(self) -> Block:
        self.consume("LBRACE", "Esperado '{' para iniciar bloco")
        statements = []
        while not self.check("RBRACE") and not self.check("EOF"):
            statements.append(self.statement())
        self.consume("RBRACE", "Esperado '}' para fechar bloco")
        return Block(statements)

    # Precedência: igualdade -> comparação -> soma/subtração -> multiplicação/divisão -> unário -> primário
    def expression(self) -> ASTNode:
        return self.equality()

    def equality(self) -> ASTNode:
        expr = self.comparison()
        while self.match("EQ", "NEQ"):
            op = self.previous().value
            right = self.comparison()
            expr = BinaryOp(expr, op, right)
        return expr

    def comparison(self) -> ASTNode:
        expr = self.term()
        while self.match("LT", "GT"):
            op = self.previous().value
            right = self.term()
            expr = BinaryOp(expr, op, right)
        return expr

    def term(self) -> ASTNode:
        expr = self.factor()
        while self.match("PLUS", "MINUS"):
            op = self.previous().value
            right = self.factor()
            expr = BinaryOp(expr, op, right)
        return expr

    def factor(self) -> ASTNode:
        expr = self.unary()
        while self.match("STAR", "SLASH"):
            op = self.previous().value
            right = self.unary()
            expr = BinaryOp(expr, op, right)
        return expr

    def unary(self) -> ASTNode:
        if self.match("MINUS"):
            return UnaryOp("-", self.unary())
        return self.primary()

    def primary(self) -> ASTNode:
        if self.match("NUMBER"):
            return Literal(int(self.previous().value), "int")
        if self.match("TRUE"):
            return Literal(True, "bool")
        if self.match("FALSE"):
            return Literal(False, "bool")
        if self.match("STRING"):
            return Literal(self.previous().value, "string")
        if self.match("READ"):
            self.consume("LPAREN", "Esperado '(' após read")
            self.consume("RPAREN", "Esperado ')' após read")
            return Read()
        if self.match("IDENT"):
            return Identifier(self.previous().value)
        if self.match("LPAREN"):
            expr = self.expression()
            self.consume("RPAREN", "Esperado ')' após expressão")
            return expr
        token = self.current()
        raise ParserError(f"Expressão inválida em {token.type} ({token.value!r}) na linha {token.line}, coluna {token.column}")
