# Compilador MiniLang em Python

Este projeto implementa um compilador didático completo para uma linguagem simples chamada **MiniLang**. Ele foi criado para atender às etapas clássicas de um compilador: análise léxica, análise sintática, análise semântica, geração de código intermediário, geração de código final e execução em uma máquina virtual.

## 1. Objetivo do projeto

O objetivo é demonstrar, na prática, conceitos de Linguagens Formais, Autômatos e Compiladores. A entrada é um programa escrito em MiniLang e a saída pode ser vista em várias etapas:

```text
Código-fonte -> Tokens -> AST -> Tabela de símbolos -> TAC -> Bytecode -> Execução
```

## 2. Como executar

Entre na pasta do projeto:

```bash
cd minilang_compiler
```

Execute um exemplo mostrando todas as etapas:

```bash
python main.py exemplos/valido1.mini --tokens --ast --symbols --ir --bytecode --run
```

Execute o exemplo com while:

```bash
python main.py exemplos/valido2_while.mini --ir --bytecode --run
```

Execute o exemplo com read:

```bash
python main.py exemplos/valido3_read.mini --run --input 8
```

Testando erro de variável não declarada:

```bash
python main.py exemplos/erro_variavel_nao_declarada.mini
```

Testando erro de tipo:

```bash
python main.py exemplos/erro_tipo.mini
```

Testando erro sintático:

```bash
python main.py exemplos/erro_sintatico.mini
```

## 3. Especificação da linguagem MiniLang

A linguagem suporta:

- Tipos: `int` e `bool`.
- Literais: números inteiros, `true`, `false` e strings para `print`.
- Declaração de variáveis.
- Atribuição.
- `if` e `else`.
- `while`.
- `print`.
- `read`.
- Operações aritméticas: `+`, `-`, `*`, `/`.
- Operações relacionais/lógicas: `==`, `!=`, `<`, `>`.
- Comentários de linha com `//`.
- Comentários de bloco com `/* ... */`.

Exemplo:

```text
int x;
int y;
bool maior;

x = 10;
y = 5;
maior = x > y;

if (maior) {
    print(x);
} else {
    print(y);
}
```

## 4. Estrutura dos arquivos

```text
minilang_compiler/
│
├── main.py              # Arquivo principal do compilador
├── lexer.py             # Analisador léxico
├── parser.py            # Analisador sintático
├── ast_nodes.py         # Definição dos nós da AST
├── semantic.py          # Analisador semântico e tabela de símbolos
├── ir_generator.py      # Geração de código intermediário TAC
├── code_generator.py    # Geração de bytecode
├── vm.py                # Máquina virtual para executar o bytecode
│
└── exemplos/
    ├── valido1.mini
    ├── valido2_while.mini
    ├── valido3_read.mini
    ├── erro_variavel_nao_declarada.mini
    ├── erro_tipo.mini
    └── erro_sintatico.mini
```

## 5. Explicação das etapas

### 5.1 Análise Léxica

Arquivo: `lexer.py`

O analisador léxico lê o código-fonte caractere por caractere e transforma esse texto em uma lista de tokens.

Exemplo:

```text
int x;
```

Gera:

```text
Token(INT, 'int')
Token(IDENT, 'x')
Token(SEMICOLON, ';')
```

Essa etapa reconhece palavras reservadas, identificadores, números, strings, operadores, símbolos e comentários.

### 5.2 Análise Sintática

Arquivo: `parser.py`

O parser recebe a lista de tokens e verifica se eles estão organizados de acordo com a gramática da linguagem. Ele usa o método **descendente recursivo**.

Exemplo:

```text
x = 10 + 5;
```

Vira uma árvore parecida com:

```text
Assignment
 ├── x
 └── BinaryOp(+)
      ├── 10
      └── 5
```

### 5.3 AST

Arquivo: `ast_nodes.py`

A AST é a Árvore de Sintaxe Abstrata. Ela representa o programa em forma de árvore, facilitando a análise semântica e a geração de código.

Principais nós:

- `Program`
- `VarDecl`
- `Assignment`
- `Print`
- `If`
- `While`
- `BinaryOp`
- `Literal`
- `Identifier`

### 5.4 Análise Semântica

Arquivo: `semantic.py`

A análise semântica verifica se o programa faz sentido logicamente.

Ela detecta erros como:

```text
x = 10;
```

Erro: variável `x` não foi declarada.

Outro exemplo:

```text
int x;
x = true;
```

Erro: `x` é inteiro, mas recebeu booleano.

Também existe uma tabela de símbolos que guarda o nome e o tipo das variáveis.

### 5.5 Código Intermediário

Arquivo: `ir_generator.py`

O código intermediário é gerado em formato parecido com Código de Três Endereços, também chamado de TAC.

Exemplo:

```text
x = 10 + 5 * 2;
```

Pode virar:

```text
t1 = 5 * 2
t2 = 10 + t1
x = t2
```

Essa etapa deixa o código mais simples para uma futura otimização ou geração de código final.

### 5.6 Código Final

Arquivo: `code_generator.py`

A geração final produz um bytecode para uma máquina virtual simples.

Exemplo:

```text
x = 10;
print(x);
```

Gera:

```text
PUSH_INT 10
STORE x
LOAD x
PRINT
HALT
```

### 5.7 Máquina Virtual

Arquivo: `vm.py`

A VM interpreta o bytecode gerado. Ela possui:

- Pilha de execução.
- Dicionário de variáveis.
- Controle de labels e jumps.
- Execução de operações aritméticas e comparações.
- Comandos `PRINT` e `READ`.

## 6. Gramática simplificada

```text
program     -> statement* EOF
statement   -> varDecl | assignment | print | if | while
varDecl     -> ("int" | "bool") IDENT ";"
assignment  -> IDENT "=" expression ";"
print       -> "print" "(" expression ")" ";"
if          -> "if" "(" expression ")" block ("else" block)?
while       -> "while" "(" expression ")" block
block       -> "{" statement* "}"
expression  -> equality
equality    -> comparison (("==" | "!=") comparison)*
comparison  -> term (("<" | ">") term)*
term        -> factor (("+" | "-") factor)*
factor      -> unary (("*" | "/") unary)*
unary       -> "-" unary | primary
primary     -> NUMBER | true | false | STRING | read() | IDENT | "(" expression ")"
```

## 7. Relação com os critérios da atividade

| Critério | Como o projeto atende |
|---|---|
| Corretude léxica/sintática | `lexer.py` e `parser.py` reconhecem programas válidos e rejeitam inválidos |
| Análise semântica | `semantic.py` verifica tipos, declaração prévia e escopo |
| Geração de código | `ir_generator.py` gera TAC e `code_generator.py` gera bytecode executável |
| Documentação/código | Código organizado em módulos, com exemplos e explicação neste README |

## 8. Observação sobre Assembly

Em vez de gerar Assembly x86 ou MIPS diretamente, este projeto gera bytecode para uma máquina virtual própria. Essa escolha é adequada para fins didáticos, pois mantém a etapa de geração de código final sem depender de detalhes específicos de arquitetura de processador.

No relatório, você pode justificar assim:

> A geração de código final foi feita para uma máquina virtual própria, baseada em instruções simples de pilha. Essa abordagem permite demonstrar a tradução da linguagem-fonte para uma linguagem de baixo nível executável, mantendo o foco nas etapas fundamentais de compilação.
