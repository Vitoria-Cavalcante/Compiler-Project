import ast
from typing import List, Dict, Any, Optional


class VMError(Exception):
    pass


class VirtualMachine:
    def __init__(self, bytecode: List[str], inputs: Optional[List[int]] = None):
        self.bytecode = bytecode
        self.inputs = list(inputs or [])
        self.stack: List[Any] = []
        self.variables: Dict[str, Any] = {}
        self.labels: Dict[str, int] = {}
        self.ip = 0
        self.output: List[str] = []
        self._index_labels()

    def _index_labels(self) -> None:
        for index, instruction in enumerate(self.bytecode):
            parts = instruction.split(maxsplit=1)
            if parts and parts[0] == "LABEL":
                self.labels[parts[1]] = index

    def pop(self) -> Any:
        if not self.stack:
            raise VMError("Pilha vazia")
        return self.stack.pop()

    def run(self) -> List[str]:
        while self.ip < len(self.bytecode):
            instruction = self.bytecode[self.ip]
            self.ip += 1
            if not instruction.strip():
                continue

            parts = instruction.split(maxsplit=1)
            op = parts[0]
            arg = parts[1] if len(parts) > 1 else None

            if op == "DECLARE":
                self.variables[arg] = 0
            elif op == "PUSH_INT":
                self.stack.append(int(arg))
            elif op == "PUSH_BOOL":
                self.stack.append(arg == "true")
            elif op == "PUSH_STRING":
                self.stack.append(ast.literal_eval(arg))
            elif op == "LOAD":
                if arg not in self.variables:
                    raise VMError(f"Variável '{arg}' não existe")
                self.stack.append(self.variables[arg])
            elif op == "STORE":
                if arg not in self.variables:
                    raise VMError(f"Variável '{arg}' não existe")
                self.variables[arg] = self.pop()
            elif op == "READ":
                if self.inputs:
                    self.stack.append(int(self.inputs.pop(0)))
                else:
                    self.stack.append(int(input("read> ")))
            elif op == "PRINT":
                value = self.pop()
                text = str(value).lower() if isinstance(value, bool) else str(value)
                self.output.append(text)
                print(text)
            elif op in ("ADD", "SUB", "MUL", "DIV", "EQ", "NEQ", "LT", "GT"):
                right = self.pop()
                left = self.pop()
                if op == "ADD":
                    self.stack.append(left + right)
                elif op == "SUB":
                    self.stack.append(left - right)
                elif op == "MUL":
                    self.stack.append(left * right)
                elif op == "DIV":
                    self.stack.append(left // right)
                elif op == "EQ":
                    self.stack.append(left == right)
                elif op == "NEQ":
                    self.stack.append(left != right)
                elif op == "LT":
                    self.stack.append(left < right)
                elif op == "GT":
                    self.stack.append(left > right)
            elif op == "NEG":
                self.stack.append(-self.pop())
            elif op == "JUMP":
                self.ip = self.labels[arg]
            elif op == "JUMP_IF_FALSE":
                condition = self.pop()
                if not condition:
                    self.ip = self.labels[arg]
            elif op == "LABEL":
                pass
            elif op == "HALT":
                break
            else:
                raise VMError(f"Instrução desconhecida: {instruction}")

        return self.output
