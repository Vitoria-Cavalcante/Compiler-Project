from dataclasses import dataclass
from typing import List, Optional, Any


class ASTNode:
    pass


@dataclass
class Program(ASTNode):
    statements: List[ASTNode]


@dataclass
class Block(ASTNode):
    statements: List[ASTNode]


@dataclass
class VarDecl(ASTNode):
    var_type: str
    name: str


@dataclass
class Assignment(ASTNode):
    name: str
    value: ASTNode


@dataclass
class Print(ASTNode):
    value: ASTNode


@dataclass
class Read(ASTNode):
    pass


@dataclass
class If(ASTNode):
    condition: ASTNode
    then_branch: Block
    else_branch: Optional[Block]


@dataclass
class While(ASTNode):
    condition: ASTNode
    body: Block


@dataclass
class BinaryOp(ASTNode):
    left: ASTNode
    operator: str
    right: ASTNode


@dataclass
class UnaryOp(ASTNode):
    operator: str
    operand: ASTNode


@dataclass
class Literal(ASTNode):
    value: Any
    literal_type: str


@dataclass
class Identifier(ASTNode):
    name: str
