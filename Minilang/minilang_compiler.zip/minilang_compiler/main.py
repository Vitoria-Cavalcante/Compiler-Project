import argparse
from pprint import pprint

from lexer import Lexer, LexerError
from parser import Parser, ParserError
from semantic import SemanticAnalyzer, SemanticError
from ir_generator import IRGenerator
from code_generator import BytecodeGenerator
from vm import VirtualMachine, VMError


def compile_source(source: str):
    tokens = Lexer(source).tokenize()
    ast = Parser(tokens).parse()
    symbols = SemanticAnalyzer().analyze(ast)
    ir = IRGenerator().generate(ast)
    bytecode = BytecodeGenerator().generate(ast)
    return tokens, ast, symbols, ir, bytecode


def main():
    arg_parser = argparse.ArgumentParser(description="Compilador didático MiniLang em Python")
    arg_parser.add_argument("arquivo", help="Arquivo fonte .mini")
    arg_parser.add_argument("--tokens", action="store_true", help="Mostra os tokens")
    arg_parser.add_argument("--ast", action="store_true", help="Mostra a AST")
    arg_parser.add_argument("--symbols", action="store_true", help="Mostra a tabela de símbolos")
    arg_parser.add_argument("--ir", action="store_true", help="Mostra o código intermediário TAC")
    arg_parser.add_argument("--bytecode", action="store_true", help="Mostra o bytecode final")
    arg_parser.add_argument("--run", action="store_true", help="Executa o bytecode na VM")
    arg_parser.add_argument("--input", nargs="*", type=int, default=[], help="Valores usados pelo read(), exemplo: --input 10 20")
    args = arg_parser.parse_args()

    try:
        with open(args.arquivo, "r", encoding="utf-8") as f:
            source = f.read()

        tokens, ast, symbols, ir, bytecode = compile_source(source)

        if args.tokens:
            print("\n=== TOKENS ===")
            for token in tokens:
                print(token)

        if args.ast:
            print("\n=== AST ===")
            pprint(ast)

        if args.symbols:
            print("\n=== TABELA DE SÍMBOLOS ===")
            pprint(symbols.snapshot())

        if args.ir:
            print("\n=== CÓDIGO INTERMEDIÁRIO - TAC ===")
            for line in ir:
                print(line)

        if args.bytecode:
            print("\n=== BYTECODE ===")
            for line in bytecode:
                print(line)

        if args.run:
            print("\n=== EXECUÇÃO ===")
            VirtualMachine(bytecode, inputs=args.input).run()

        if not any([args.tokens, args.ast, args.symbols, args.ir, args.bytecode, args.run]):
            print("Compilação concluída com sucesso. Use --tokens --ast --symbols --ir --bytecode --run para ver as etapas.")

    except (LexerError, ParserError, SemanticError, VMError, FileNotFoundError) as e:
        print(f"ERRO: {e}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
