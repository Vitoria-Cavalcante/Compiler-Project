from typing import Dict, List
from ast_nodes import *


class SemanticError(Exception):
    pass


class SymbolTable:
    def __init__(self):
        # Lista de escopos. O primeiro é o escopo global.
        self.scopes: List[Dict[str, str]] = [{}]

    def enter_scope(self) -> None:
        self.scopes.append({})

    def exit_scope(self) -> None:
        self.scopes.pop()

    def declare(self, name: str, var_type: str) -> None:
        current = self.scopes[-1]
        if name in current:
            raise SemanticError(f"Variável '{name}' já declarada neste escopo")
        current[name] = var_type

    def lookup(self, name: str) -> str:
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        raise SemanticError(f"Variável '{name}' não declarada")

    def snapshot(self) -> Dict[str, str]:
        result = {}
        for scope in self.scopes:
            result.update(scope)
        return result


class SemanticAnalyzer:
    def __init__(self):
        self.symbols = SymbolTable()

    def analyze(self, program: Program) -> SymbolTable:
        for stmt in program.statements:
            self.check_statement(stmt)
        return self.symbols

    def check_statement(self, node: ASTNode) -> None:
        if isinstance(node, VarDecl):
            self.symbols.declare(node.name, node.var_type)
            return

        if isinstance(node, Assignment):
            expected_type = self.symbols.lookup(node.name)
            actual_type = self.check_expression(node.value)
            if expected_type != actual_type:
                raise SemanticError(f"Tipo incompatível em '{node.name}': esperado {expected_type}, recebido {actual_type}")
            return

        if isinstance(node, Print):
            expr_type = self.check_expression(node.value)
            if expr_type not in ("int", "bool", "string"):
                raise SemanticError("Tipo inválido no print")
            return

        if isinstance(node, If):
            cond_type = self.check_expression(node.condition)
            if cond_type != "bool":
                raise SemanticError("Condição do if deve ser booleana")
            self.check_block(node.then_branch)
            if node.else_branch:
                self.check_block(node.else_branch)
            return

        if isinstance(node, While):
            cond_type = self.check_expression(node.condition)
            if cond_type != "bool":
                raise SemanticError("Condição do while deve ser booleana")
            self.check_block(node.body)
            return

        raise SemanticError(f"Nó semântico não suportado: {type(node).__name__}")

    def check_block(self, block: Block) -> None:
        self.symbols.enter_scope()
        for stmt in block.statements:
            self.check_statement(stmt)
        self.symbols.exit_scope()

    def check_expression(self, node: ASTNode) -> str:
        if isinstance(node, Literal):
            return node.literal_type

        if isinstance(node, Identifier):
            return self.symbols.lookup(node.name)

        if isinstance(node, Read):
            # Para simplificar, read() retorna int.
            return "int"

        if isinstance(node, UnaryOp):
            operand_type = self.check_expression(node.operand)
            if node.operator == "-" and operand_type == "int":
                return "int"
            raise SemanticError(f"Operador unário '{node.operator}' inválido para tipo {operand_type}")

        if isinstance(node, BinaryOp):
            left_type = self.check_expression(node.left)
            right_type = self.check_expression(node.right)
            op = node.operator

            if op in ("+", "-", "*", "/"):
                if left_type == right_type == "int":
                    return "int"
                raise SemanticError(f"Operador '{op}' exige operandos inteiros")

            if op in ("<", ">"):
                if left_type == right_type == "int":
                    return "bool"
                raise SemanticError(f"Operador '{op}' exige operandos inteiros")

            if op in ("==", "!="):
                if left_type == right_type:
                    return "bool"
                raise SemanticError(f"Operador '{op}' exige operandos do mesmo tipo")

        raise SemanticError(f"Expressão não suportada: {type(node).__name__}")
